import 'package:flutter/material.dart';
import 'package:badges/badges.dart' as badges;

class TestingBottom extends StatefulWidget {
  const TestingBottom({super.key});

  @override
  _TestingBottomState createState() => _TestingBottomState();
}

class _TestingBottomState extends State<TestingBottom> {
  int _currentIndex = 1; // Start at the 'Favorites' page

  void _onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: [
          HomePage(),
          FavoritesPage(),
          CartPage(),
          ProfilePage(),
        ],
      ),
      bottomNavigationBar: BottomAppBar(
        shape: const CircularNotchedRectangle(),
        notchMargin: 8.0,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            // Home Tab
            ButtonContainer(
              isSelected: _currentIndex == 0,
              label: "Home",
              child: IconButton(
                icon: const Icon(Icons.home),
                color: _currentIndex == 0 ? Colors.white : Colors.grey,
                onPressed: () => _onTabTapped(0),
              ),
            ),
            // Favorites Tab
            ButtonContainer(
              isSelected: _currentIndex == 1,
              label: "Favorites",
              child: IconButton(
                icon: const Icon(Icons.favorite_border),
                color: _currentIndex == 1 ? Colors.white : Colors.grey,
                onPressed: () => _onTabTapped(1),
              ),
            ),
            const SizedBox(width: 40), // Space for FloatingActionButton
            // Cart Tab
            ButtonContainer(
              isSelected: _currentIndex == 2,
              label: "Cart",
              badgeCount: 3, // Example: Show a badge with count 3
              child: IconButton(
                icon: const Icon(Icons.shopping_cart),
                color: _currentIndex == 2 ? Colors.white : Colors.grey,
                onPressed: () => _onTabTapped(2),
              ),
            ),

            // Profile Tab
            ButtonContainer(
              isSelected: _currentIndex == 3,
              label: "Profile",
              child: IconButton(
                icon: const Icon(Icons.person_outline),
                color: _currentIndex == 3 ? Colors.white : Colors.grey,
                onPressed: () => _onTabTapped(3),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.purple,
        child: const Icon(Icons.add, color: Colors.white),
        onPressed: () {},
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}


class ButtonContainer extends StatelessWidget {
  final Widget child;
  final bool isSelected;
  final String label;
  final int? badgeCount; // Badge count for specific tabs (e.g., Cart)

  const ButtonContainer({
    Key? key,
    required this.child,
    required this.isSelected,
    required this.label,
    this.badgeCount, 
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 7),
          decoration: BoxDecoration(
            color: isSelected ? const Color(0xff7963EA) : Colors.transparent,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              badges.Badge(
                showBadge: badgeCount != null && badgeCount! > 0,
                badgeContent: badgeCount != null && badgeCount! > 0
                    ? Text(
                        badgeCount.toString(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      )
                    : null, 
                badgeStyle: badges.BadgeStyle(
                  padding: EdgeInsets.all(7),
                  badgeColor: const Color(0xff7963EA), 
                  shape: badges.BadgeShape.circle, 
                  borderSide: BorderSide(color: Colors.white),
                  borderRadius: BorderRadius.circular(10),
                  elevation: 0, 
                ),
                position: badges.BadgePosition.custom(
                  top: -7,
                  
                  end: isSelected ? -37 : 8, 
                ),
                child: child,
              ),
              if (isSelected) ...[
                Text(
                  label,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }
}


class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Welcome to Home Page!',
        style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
      ),
    );
  }
}

class FavoritesPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Welcome to Favorites Page!',
        style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
      ),
    );
  }
}

class CartPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Your cart items will appear here.',
        style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
      ),
    );
  }
}

class ProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Welcome to Profile Page!',
        style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
      ),
    );
  }
}
