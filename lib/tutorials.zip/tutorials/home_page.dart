import 'package:flutter/material.dart';
import 'package:iconly/iconly.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<String> categoriesimageUrl = [
    "accessories.png",
    "hand_watch.png",
    "headphone.png",
    "photography.png",
    "game.png",
    "pc.png"
  ];
  final List<String> categoriesNames = [
    "Accessories",
    "Hand Watch",
    "Headphone",
    "Photography",
    "Game",
    "PC"
  ];
  final List<Color> colors = [
    Color(0xffEEF8F0),
    Color(0xffF8EFEA),
    Color(0xffFFF1EE),
    Color(0xffEAEFF3),
    Color(0xff9CCECE),
    Color(0xff7AC4B2)
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffF7F6FB),
      appBar: AppBar(
        backgroundColor: Color(0xffF7F6FB),
        leadingWidth: 200,
        elevation: 0,
        leading: Row(
          children: [
            Container(
                width: 40,
                height: 40,
                margin: EdgeInsets.only(left: 10),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10)),
                child: Icon(IconlyBold.location)),
            SizedBox(
              width: 10,
            ),
            Text(
              "Home",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
            ),
            Icon(Icons.arrow_drop_down)
          ],
        ),
        actions: [
          Container(
            width: 40,
            height: 40,
            alignment: Alignment.center,
            margin: EdgeInsets.only(right: 10),
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(10)),
            child: Stack(children: [
              Positioned(right: 0, child: Badge()),
              Icon(IconlyBold.notification)
            ]),
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Container(
                      decoration: BoxDecoration(boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withValues(alpha: .1),
                          spreadRadius: 1,
                          blurRadius: 5,
                          offset: Offset(0, 3),
                        )
                      ]),
                      child: TextField(
                        decoration: InputDecoration(
                            hintText: "Search",
                            prefixIcon: Icon(Icons.search),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide.none),
                            filled: true,
                            fillColor: Colors.white),
                      ),
                    ),
                  ),
                ),
                Container(
                    margin: EdgeInsets.only(right: 10),
                    padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                    decoration: BoxDecoration(
                        color: Color(0xff7963EA),
                        borderRadius: BorderRadius.circular(15)),
                    child: Icon(
                      IconlyBold.filter,
                      color: Colors.white,
                    ))
              ],
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              child: Align(
                alignment: Alignment.topLeft,
                child: RichText(
                    textAlign: TextAlign.start,
                    text: TextSpan(children: [
                      TextSpan(
                          text: 'Got Delivered ',
                          style: TextStyle(color: Colors.black, fontSize: 18)),
                      TextSpan(
                          text: 'everything you need',
                          style: TextStyle(color: Colors.grey, fontSize: 17))
                    ])),
              ),
            ),
            GridView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: colors.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                ),
                itemBuilder: (ctx, index) {
                  return Container(
                    margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                    padding: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withValues(alpha: .2),
                            spreadRadius: 1,
                            blurRadius: 5,
                            offset: Offset(0, 3),
                          )
                        ],
                        borderRadius: BorderRadius.circular(15)),
                    child: Column(
                      children: [
                        Flexible(
                          child: Container(
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                color: colors[index],
                                image: DecorationImage(
                                    image: AssetImage(
                                  "assets/images/${categoriesimageUrl[index]}",
                                ))),
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Text(
                          categoriesNames[index],
                          style: TextStyle(fontSize: 17),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                            alignment: Alignment.center,
                            width: 90,
                            height: 20,
                            decoration: BoxDecoration(
                                color: Color(0xffEEEDF2),
                                borderRadius: BorderRadius.circular(5)),
                            child: Text(
                              "12 Items",
                              style: TextStyle(color: Colors.grey),
                            ))
                      ],
                    ),
                  );
                })
          ],
        ),
      ),
    );
  }
}
