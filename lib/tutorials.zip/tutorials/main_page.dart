import 'package:flutter/material.dart';
import 'package:flutter_tutoial/cart_page.dart';
import 'package:flutter_tutoial/home_page.dart';
import 'package:iconly/iconly.dart';

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  final List<Widget> _pages = [
    HomePage(),
    CartPage(),
    Container(),
    Container()
  ];
  int _currentIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages.elementAt(_currentIndex),
      bottomNavigationBar: BottomNavigationBar(
          onTap: (index) {
            setState(() {
              _currentIndex = index;
            });
          },
          type: BottomNavigationBarType.fixed,
          selectedItemColor: Color(0xff7963EA),
          backgroundColor: Colors.white,
          items: [
            BottomNavigationBarItem(
                icon: Icon(IconlyBold.home), label: "Home", tooltip: "Home"),
            BottomNavigationBarItem(
                icon: Badge(child: Icon(Icons.shopping_bag)),
                label: "Cart",
                tooltip: "Cart"),
            BottomNavigationBarItem(
                icon: Icon(Icons.shopping_bag), label: "Cart", tooltip: "Cart"),
            BottomNavigationBarItem(
                icon: Icon(IconlyBold.setting),
                label: "Settings",
                tooltip: "Settings"),
          ]),
    );
  }
}
