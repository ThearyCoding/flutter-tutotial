import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:iconly/iconly.dart';

class CartPage extends StatefulWidget {
  const CartPage({super.key});

  @override
  State<CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color(0xffF7F6FC),
        appBar: AppBar(
          backgroundColor: Color(0xffF7F6FC),
          title: Text(
            "My Cart",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          centerTitle: true,
        ),
        body: Column(
          children: [
            Expanded(
                child: ListView.builder(
                    itemCount: Product.products.length,
                    itemBuilder: (ctx, index) {
                      final product = Product.products[index];
                      return Slidable(
                        key: ValueKey(index),
                        endActionPane: ActionPane(
                          motion: ScrollMotion(),
                          children: [
                            CustomSlidableAction(
                                padding: EdgeInsets.all(10),
                                borderRadius: BorderRadius.circular(15),
                                backgroundColor: Color(0xffFE474C),
                                onPressed: (context) {
                                  setState(() {
                                    Product.products.removeAt(index);
                                  });
                                },
                                child: Icon(
                                  IconlyBold.delete,
                                  size: 25,
                                ))
                          ],
                        ),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 20, vertical: 5),
                          margin:
                              EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                          decoration: BoxDecoration(
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withValues(alpha: .2),
                                  spreadRadius: 1,
                                  blurRadius: 5,
                                  offset: Offset(0, 3),
                                )
                              ],
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.white),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                width: 100,
                                height: 100,
                                margin: EdgeInsets.symmetric(horizontal: 10),
                                decoration: BoxDecoration(
                                    image: DecorationImage(
                                        image: AssetImage(
                                            'assets/images/${product.imageUrl}'))),
                              ),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      product.name,
                                      style: TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.w600),
                                    ),
                                    Text(
                                      product.category,
                                      style: TextStyle(color: Colors.grey),
                                    ),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Text(
                                            '\$${product.price.toStringAsFixed(2)}',
                                            style: TextStyle(
                                                color: Colors.black,
                                                fontSize: 15,
                                                fontWeight: FontWeight.w500),
                                          ),
                                        ),
                                        Row(
                                          spacing: 8,
                                          children: [
                                            Container(
                                                width: 30,
                                                height: 30,
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            7),
                                                    color:
                                                        Colors.grey.shade300),
                                                child: Icon(
                                                  Icons.remove,
                                                  color: Colors.black,
                                                )),
                                            Text("3"),
                                            Container(
                                                width: 30,
                                                height: 30,
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            7),
                                                    color: Color(0xff7963EA)),
                                                child: Icon(
                                                  Icons.add,
                                                  color: Colors.white,
                                                ))
                                          ],
                                        )
                                      ],
                                    ),
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                      );
                    })),
            Padding(
              padding: const EdgeInsets.all(40),
              child: Row(
                spacing: 20,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Total \$100 ",
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                  Container(
                    width: 150,
                    height: 50,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Color(0xff7963EA)),
                    child: Text("CheckOut",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w400)),
                  )
                ],
              ),
            )
          ],
        ));
  }
}

class Product {
  final String id;
  final String name;
  final String imageUrl;
  final double price;
  final String category;

  Product(
      {required this.id,
      required this.category,
      required this.name,
      required this.imageUrl,
      required this.price});

  static List<Product> products = [
    Product(
      id: '1',
      name: 'Uniform Wares M35',
      imageUrl: '12926866_14255198_600.jpg',
      category: 'Hand Watch',
      price: 200.6,
    ),
    Product(
      id: '2',
      name: 'AirPods Pro 2nd Generation',
      imageUrl: 'airpods-pro-2nd-generation-8deGVY7-600.jpg',
      category: 'HeadPhones',
      price: 150.6,
    ),
    Product(
      id: '3',
      name: 'Beats Solo 2 Wireless',
      imageUrl: 'GUEST_c48295e8-f202-443f-85d2-b1de65f88bcd.webp',
      category: 'HeadPhones',
      price: 100.6,
    ),
  ];
}
